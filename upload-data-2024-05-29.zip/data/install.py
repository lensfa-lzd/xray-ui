# python -m playwright codegen --target python -o test.py -b chromium https://awsomeday-namer.virtual.awsevents.com/register
import time

from playwright.sync_api import Playwright, sync_playwright, expect


def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch_persistent_context(
        user_data_dir=user_data,
        headless=False,
        args=[
            f"--disable-extensions-except={path_to_extension}",
            f"--load-extension={path_to_extension}",
        ],
    )

    page = browser.new_page()
    page.goto('https://bt.cn', timeout=3600 * 1000)

    time.sleep(3600)

    page.close()
    browser.close()


if __name__ == "__main__":
    print()

    user_data = 'D:\\id_tools\\data\\base'
    path_to_extension = 'D:\\id_tools\\data\\extension\\Buster,' \
                        'D:\\id_tools\\data\\extension\\google_translate,' \
                        'D:\\id_tools\\data\\extension\\2Captcha'

    with sync_playwright() as playwright:
        run(playwright)
