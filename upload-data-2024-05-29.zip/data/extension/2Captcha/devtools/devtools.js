chrome.devtools.panels.create("2Captcha Detector", "assets/images/logo.svg", "app/index.html");
