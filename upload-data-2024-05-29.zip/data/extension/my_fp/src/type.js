const Mode = {
    enable: '0',
    seed: '1',
    config: '2',
    basic: 'a',
    special: 'b',
    ip: 'ip',
}

const Control = {
    navigator: 0,
    screen: 1,
}

const SelectOpt = {
    default: {k: '0', v: "系统值"},
    page: {k: '1', v: "根据标签页随机"},
    browser: {k: '2', v: "每次启动浏览器随机"},
    domain: {k: '3', v: "根据域名随机"},

    localhost: {k: '10', v: "替换为127.0.0.1"},
    proxy: {k: '11', v: "替换为代理公网ip"},
}

const timeOpt = [
{
  "text": "新加坡",
  "zone": "Asia/Singapore",
  "locale": "en-SG",
  "offset": 8
}
]


const BasicConf = {
    language: 0,
    platform: 1,
    hardwareConcurrency: 2,
    appVersion: 3,
    userAgent: 4,

    height: 10,
    width: 11,
    colorDepth: 12,
    pixelDepth: 13,
}

const SpecialConf = {
    languages: 20,
    canvas: 21,
    timezone: 22,
    audio: 23,
    webgl: 24,
    webrtc: 25,
}