const Mode = {
    enable: '0',
    seed: '1',
    config: '2',
    basic: 'a',
    special: 'b',
    ip: 'ip',
}

const Control = {
    navigator: 0,
    screen: 1,
}

const Opt = {
    default: '0',
    page: '1',
    browser: '2',
    domain: '3',

    localhost: '10',
    proxy: '11',
}

const Item = {
    language: 0,
    platform: 1,
    hardwareConcurrency: 2,
    appVersion: 3,
    userAgent: 4,

    height: 10,
    width: 11,
    colorDepth: 12,
    pixelDepth: 13,

    languages: 20,
    canvas: 21,
    timezone: 22,
    audio: 23,
    webgl: 24,
    webrtc: 25,
}

/**
 * 各标签页的通知内容
 */
const notify = {}
const customConf = {
  "language": "en-SG",
  "platform": "Win64",
  "hardwareConcurrency": 12,
  "memory": 64,
  "appVersion": "5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/604.3 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/604.3",
  "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/604.3 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/604.3",
  "ver": "125",
  "ua_platform": "Windows",
  "sec_ch_ua": "\"Google Chrome\";v=\"125\",\"Chromium\";v=\"125\",\"Not-A.Brand\";v=\"99\"",
  "sec_ch_ua_mobile": "?0",
  "sec_ch_ua_platform": "\"Windows\"",
  "height": 2160,
  "width": 3840,
  "lan_ip": "10.8.176.196",
  "seed": 33219
}

/**
 * 扩展初始化
 * @param {string} prevVersion 上个版本号
 */
const init = async function (prevVersion) {
    // get data
    const data = await chrome.storage.local.get();
    // console.log(data[Mode.basic])
    // get manifest
    let manifest = chrome.runtime.getManifest()
    let currVersion = manifest.version  // 扩展当前版本号

    // 若已初始化，跳过
    if (data[`init-${currVersion}`]) return

    // enable
    data[Mode.enable] = data[Mode.enable] ?? true;

    // seed 可以通过固定种子来确定唯一值
    // data[Mode.seed] = Math.floor(Math.random() * 100000);
    data[Mode.seed] = customConf.seed;

    // control
    data[Mode.config] = Object.assign({
        [Control.navigator]: true,
        [Control.screen]: true,
    }, data[Mode.config])
    // basic
    data[Mode.basic] = Object.assign({
        // 0 为预设 1为 自定义: 手动输入值
        [Item.language]: {select: 1, value: customConf.language},
        [Item.platform]: {select: 1, value: customConf.platform},
        [Item.hardwareConcurrency]: {select: 1, value: customConf.hardwareConcurrency},
        [Item.appVersion]: {select: 1, value: customConf.appVersion},
        [Item.userAgent]: {select: 1, value: customConf.userAgent},

        [Item.height]: {select: 1, value: customConf.height},
        [Item.width]: {select: 1, value: customConf.width},
        [Item.colorDepth]: {select: 1, value: 24},
        [Item.pixelDepth]: {select: 1, value: 24},
    }, data[Mode.basic])
    // spacial
    data[Mode.special] = Object.assign({
        [Item.languages]: Opt.browser,

        [Item.canvas]: Opt.browser,
        [Item.audio]: Opt.browser,

        [Item.webgl]: Opt.browser,
        [Item.timezone]: 0,
        [Item.webrtc]: Opt.proxy,
    }, data[Mode.special])
    // 获取ip
    rePubIP()

    // save
    chrome.storage.local.set(data);
    chrome.storage.local.set({[`init-${currVersion}`]: true})  // 初始化成功标志
    if (prevVersion) chrome.storage.local.remove(`init-${prevVersion}`)
}

/**
 * 初次启动扩展时触发（浏览器更新、扩展更新也触发）
 * @param {'install' || 'update' || 'chrome_update' } reason 操作
 * @param {string} previousVersion 上个版本号
 */
chrome.runtime.onInstalled.addListener(({reason, previousVersion}) => {
    init(previousVersion);
});

/**
 * 重启浏览器触发
 */
// chrome.runtime.onStartup.addListener(() => {
//     // seed
//     chrome.storage.local.set({
//         [Mode.seed]: Math.floor(Math.random() * 100000)
//     });
//     // 获取ip
//     rePubIP()
// });

let isGettingIP = false
/**
 * 重新获取公网ip并存储 // 重置为指定的内网ip
 */
const rePubIP = function () {
    if (isGettingIP) return
    isGettingIP = true
    chrome.storage.local.set({
        [Mode.ip]: customConf.lan_ip
    });
    isGettingIP = false

    // fetch('https://api.ipify.org?format=json', {method: 'GET',})
    //     .then(response => response.json())
    //     .then((data) => {
    //         if (!data.ip) return
    //         chrome.storage.local.set({
    //             [Mode.ip]: data.ip
    //         });
    //     })
    //     .finally(() => {
    //         isGettingIP = false
    //     })
}

/**
 * tab每次加载触发
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status == 'loading') {
        // notify
        delete notify[tabId];
        chrome.action.setBadgeText({tabId, text: ''});
    }
});

/**
 * 监听tab关闭
 */
chrome.tabs.onRemoved.addListener((tabId) => {
    delete notify[tabId];
})

/**
 * 监听扩展消息
 */
chrome.runtime.onMessage.addListener((data, sender) => {
    switch (data.type) {
        case 'notify':
            handleNotify(sender.tab.id, data.value)
            break
        case 're-ip':
            rePubIP()
            break
        default:
            return
    }
})

const bgColorMap = {
    'low': '#7FFFD4',
    'high': '#F4A460',
}
const fontColorMap = {
    'record': '#FFF',
}

/**
 * 处理可疑记录
 * @param {number} tabId
 * @param {{total: number, stotal: number, seed: number}} data
 */
const handleNotify = function (tabId, data) {
    let total = 0;
    let stotal = 0;
    let tabData = notify[tabId];
    if (tabData) {
        tabData[data.seed] = {total: data.total, stotal: data.stotal};
        for (let k in tabData) {
            let d = tabData[k]
            total += d.total;
            stotal += d.stotal;
        }
    } else {
        total = data.total
        stotal = data.stotal
        notify[tabId] = {[data.seed]: {total, stotal}}
    }
    let showTotal = stotal > 0 ? stotal : total
    let showColor = bgColorMap[stotal > 0 ? 'high' : 'low']
    showTotalStr = showTotal > 99 ? '99+' : showTotal.toString()

    chrome.action.setBadgeText({tabId, text: showTotalStr});
    // chrome.action.setBadgeTextColor({tabId, color: getFontColor(showColor)});
    chrome.action.setBadgeBackgroundColor({tabId, color: showColor});
}